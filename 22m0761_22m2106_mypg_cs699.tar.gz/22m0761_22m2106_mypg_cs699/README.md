
```
SL-Project
├─ Procfile
├─ __pycache__
│  └─ database.cpython-310.pyc
├─ app.py
├─ database.py
├─ requirements.txt
├─ static
│  ├─ css
│  │  ├─ devs.css
│  │  ├─ facdashboard.css
│  │  ├─ forget.css
│  │  ├─ index.css
│  │  ├─ nav.css
│  │  ├─ signinfac.css
│  │  ├─ signinstud.css
│  │  ├─ signupfac.css
│  │  ├─ signupstud.css
│  │  └─ studashboard.css
│  ├─ favicon.ico
│  └─ img
│     ├─ devs.gif
│     ├─ mypg-logo.png
│     ├─ professor.gif
│     ├─ student.gif
│     └─ whitebg1.webp
└─ templates
   ├─ devs.html
   ├─ facdashboard.html
   ├─ forget.html
   ├─ index.html
   ├─ nav.html
   ├─ signinfac.html
   ├─ signinstud.html
   ├─ signupfac.html
   ├─ signupstud.html
   └─ studashboard.html

```